from task import Task
from task_manager import TaskManager

def menu():
    print("\nTask Manager")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Edit Task")
    print("4. Delete Task")
    print("5. Mark Complete/Incomplete")
    print("6. Exit")

def main():
    tm = TaskManager()
    while True:
        menu()
        choice = input("Enter choice: ")

        if choice == "1":
            title = input("Task title: ")
            due_date = input("Due date (optional): ")
            task = Task(title, due_date)
            tm.add_task(task)

        elif choice == "2":
            for i, task in enumerate(tm.view_tasks()):
                print(f"{i}. {task}")

        elif choice == "3":
            index = int(input("Task number to edit: "))
            new_title = input("New title: ")
            tm.edit_task(index, new_title)

        elif choice == "4":
            index = int(input("Task number to delete: "))
            tm.delete_task(index)

        elif choice == "5":
            index = int(input("Task number: "))
            status = input("Mark as complete (y/n)? ").lower() == 'y'
            tm.mark_task(index, status)

        elif choice == "6":
            break

        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()