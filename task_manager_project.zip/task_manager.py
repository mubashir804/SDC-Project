class TaskManager:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append(task)

    def view_tasks(self):
        return self.tasks

    def delete_task(self, index):
        if 0 <= index < len(self.tasks):
            del self.tasks[index]

    def edit_task(self, index, new_title):
        if 0 <= index < len(self.tasks):
            self.tasks[index].title = new_title

    def mark_task(self, index, complete=True):
        if 0 <= index < len(self.tasks):
            if complete:
                self.tasks[index].mark_complete()
            else:
                self.tasks[index].mark_incomplete()