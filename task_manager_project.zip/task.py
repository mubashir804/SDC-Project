from datetime import datetime

class Task:
    def __init__(self, title, due_date=None):
        self.title = title
        self.due_date = due_date
        self.completed = False

    def mark_complete(self):
        self.completed = True

    def mark_incomplete(self):
        self.completed = False

    def __str__(self):
        status = "✔" if self.completed else "✘"
        due = f" (Due: {self.due_date})" if self.due_date else ""
        return f"[{status}] {self.title}{due}"