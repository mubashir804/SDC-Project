import unittest
from task import Task
from task_manager import TaskManager

class TestTaskManager(unittest.TestCase):
    def test_add_and_view_task(self):
        tm = TaskManager()
        t = Task("Test Task")
        tm.add_task(t)
        self.assertEqual(len(tm.view_tasks()), 1)

    def test_delete_task(self):
        tm = TaskManager()
        tm.add_task(Task("A"))
        tm.delete_task(0)
        self.assertEqual(len(tm.view_tasks()), 0)

    def test_edit_task(self):
        tm = TaskManager()
        tm.add_task(Task("Old"))
        tm.edit_task(0, "New")
        self.assertEqual(tm.view_tasks()[0].title, "New")

if __name__ == '__main__':
    unittest.main()